# The CAM Group Website

This is the website of our academic research group at the Institute for Manufacturing in the Department of Engineering at the University of Cambridge.

This website is powered by Jekyll and some Bootstrap, Bootwatch. We tried to make it simple yet adaptable, so that it is easy for you to use it as a template. Plese feel free to copy and modify for your own purposes.

Thanks to the [Allan Lab](http://www.allanlab.org/) for providing the basis for this site. Source available [here](https://github.com/mpa139/allanlab).


Copyright CAM Group. Code released under the MIT License.

